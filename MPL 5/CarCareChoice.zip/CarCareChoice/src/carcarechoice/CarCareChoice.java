package carcarechoice;
import java.util.Scanner;

/**
 *
 * @author marcusmacair
 */
public class CarCareChoice {

    public static void main(String[] args) {
        
       int Answer;
        
//Print messages displaying available services
       System.out.println("List of our available services: ");
       System.out.println("");
       System.out.println("Oil Change");
       System.out.println("Tire Rotation");
       System.out.println("Battery Check");
       System.out.println("Brake Inspection");
       
       //Do-While loop that allows user to check multiple services
       do
       {
       //Prompt user to input name of desired service
       System.out.println("Input name of desired service (IN LOWER CASE!): ");
       
       Scanner scan = new Scanner(System.in);
       
       String ChoiceService = scan.nextLine();
       
       //Switch cases that output name and price depending on service entered
       switch (ChoiceService)
       {
            case "oil change":
                System.out.println("Oil Change: $25" );
                break;
            case "tire rotation":
                System.out.println("Tire Rotation: $22 " );
                break;
            case "battery check":
                System.out.println("Battery Check: $15" );
                break;
            case "brake inspection":
                System.out.println("Brake Inspection: $5" );
                break;
            default:
                System.out.println("Not an offered service"+
                        "(Check spelling/CASE SENSITIVE)");
                break;
        }
       
       //print message asking whether or not to check another service
       System.out.println("Check another service?  Enter 1 for yes. 2 for no");
       
       Answer = scan.nextInt();
       }
       while (Answer == 1); //loop continues if answer is yes, terminates if no
       
       
    }
    
}
