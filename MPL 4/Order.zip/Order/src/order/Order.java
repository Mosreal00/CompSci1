package order;
//Program gets 3 integers from user and displays them in both ascending 
//and descending order

import java.util.Scanner;

public class Order 
{

    
public static void main(String[] args) 
{
//declaration of variables to be assigned values given by the user
// and variables whose value will be determined by if-else statements
    
  int number1, number2, number3, min, mid, max;
    
Scanner scan = new Scanner(System.in);

// prompt for user to input three integer values
// values are assigned to three variables

System.out.println("Input three intergers: ");

number1 = scan.nextInt();
number2 = scan.nextInt();
number3 = scan.nextInt();

//if-else process to determine min value
if (number1 < number2)
    if (number1 < number3)
    min = number1;
    else
    min = number3;
    
else
    if (number2 < number3)
    min = number2;
    else
    min = number3;

//if-else process to determine mid value
if (number1 < number2)
    if (number2 < number3)
        mid = number2;
    else
        mid = number3;
else
    if (number2 < number3)
        mid = number3;
    else 
        mid = number2;

//if-else process to determind max value
 if (number1 > number2)
     if (number1 > number3)
         max = number1;
     else 
         max = number3;
 else
     if (number2 > number3)
         max = number2;
      else
         max = number3;
 
 //print statements for values in ascending and descending order
System.out.println("Ascending Order: "+min+ ", "+mid+", "+max);
System.out.println("Descending Order: "+max+ ", "+mid+", "+min);
}
    
}
