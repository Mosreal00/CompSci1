
package songlyrics;

public class SongLyrics {

   
    public static void main(String[] args) 
    {
       // Series of println objects that send a string of text to the user screen
       // Each println object contains a text string that quotes a line of a song
       // The song is "Horse with No Name" - America
        
        System.out.println("I've been through the desert on a horse with no name");
        System.out.println("It felt good to be out of the rain");
        System.out.println("In the desert you can remember your name");
        System.out.println("Cause there ain't no one for to give you no pain");
    }
    
    
}
