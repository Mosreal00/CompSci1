/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviequoteinfo;

/**
 *
 * @author marcusmacair
 */
public class MovieQuoteInfo {

    public static void main(String[] args)
    {
       System.out.println ("You want me on that wall!  You NEED me on that wall!");
       System.out.println("A Few Good Men");
       System.out.println ("Col. Nathan R. Jessep");
       System.out.println("1992");
    }
    
    
}
