
package mplquartstogallons;
//Program takes given number of quarts and determines how many gallons
//and quarts of paint are required for a job.
public class MPLQuartstoGallons {

    
    public static void main(String[] args) 
    {
       //number of quarts in a gallon set and assigned as a constant 
       //number of quarts required for job assigned to int variable
       final int QuartsinGallon = 4;
       int QuartsNeeded = 18;
       
       //Message output that tells number of gallons and quarts required
       //Message contains computations that determine number of gallons
       //and quarts from given number and given constant for quarts in gallon
       System.out.println("A job that requires " + QuartsNeeded + " quarts"
               +" requires "+(QuartsNeeded/QuartsinGallon) + " gallons and " 
               +(QuartsNeeded - ((QuartsNeeded/QuartsinGallon)*QuartsinGallon)) 
               + " quarts." );
       
    }
    
}
