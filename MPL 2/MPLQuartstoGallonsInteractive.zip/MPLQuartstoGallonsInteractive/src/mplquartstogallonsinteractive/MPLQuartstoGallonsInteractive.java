
package mplquartstogallonsinteractive;
//Given input from the user, program determines the number of gallons
//and quarts of paint required for a job.

import java.util.Scanner;


public class MPLQuartstoGallonsInteractive {

   
    public static void main(String[] args) 
    {
        
       final int QuartsinGallon = 4;
       int QuartsNeeded;
       
        Scanner scan = new Scanner(System.in);
        
        //Message prompting user to give number of quarts needed for job
        System.out.println("Please input the number of quarts needed:");
        
        //value obtained from user assigned to Quartsneeded variable
        QuartsNeeded = scan.nextInt();
        
        //Message output that tells number of gallons and quarts required
       //Message contains computations that determine number of gallons
       //and quarts from user number and given constant for quarts in gallon
        System.out.println("A job that requires " + QuartsNeeded + " quarts"
               +" requires "+(QuartsNeeded/QuartsinGallon) + " gallons and " 
               +(QuartsNeeded - ((QuartsNeeded/QuartsinGallon)*QuartsinGallon)) 
               + " quarts." );
        
        
    }
    
}
