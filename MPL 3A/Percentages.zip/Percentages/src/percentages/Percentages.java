
package percentages;

import java.util.Scanner;

public class Percentages 
{

   
    public static void main(String[] args) 
    {
        // declaration of two type double variables
        double ValueOne, ValueTwo; 
        
        // New Scanner object created
        Scanner scan = new Scanner(System.in);
        
        //Message Prompting user to input value
        System.out.println("Input Value 1: ");
        
        //input value from user assigned to first variable
        ValueOne = scan.nextDouble();
        
        System.out.println("Input Value 2: ");
        
        //input value from user assigned to second variable
        ValueTwo = scan.nextDouble();
        
        //calls to created computePercent method
        //the second call inputs the given values to the method in reverse order
        computePercent( ValueOne, ValueTwo);
        computePercent( ValueTwo, ValueOne);
        
        
    }
        //method takes two values given by the user
    public static void computePercent(double FirstValue, double SecondValue) 
    {
        double PercentTotal;
        
         //computes the first as a percentage of the second
        PercentTotal = ((FirstValue / SecondValue) * 100);
        
        System.out.println(FirstValue+ " is "+PercentTotal+"% of "+SecondValue);
        
    }
    
}
