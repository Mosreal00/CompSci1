package eggs;
//Program computes pricing for order of eggs at a rate of $3.25 per dozen and
// $.45 for individual eggs

import java.util.Scanner;

public class Eggs {

    
    public static void main(String[] args)
    {
        int NumberofEggs, EggsDozens, EggsRemainder;
        
        double TotalPrice;
        
        Scanner scan = new Scanner(System.in);
        
        //Message Prompting user to input number of eggs ordered
        System.out.println("Please Input Number of Eggs: ");
        
        //Value given by user assigned to NumberofEggs variable
        NumberofEggs = scan.nextInt();
        
        //Determine how many groups of 12 can be formed from number of Eggs given
        EggsDozens = (NumberofEggs / 12);
        
        //Computer remainder number of eggs after all groups of 12 are formed
        EggsRemainder = (NumberofEggs % 12);
        
        //Total price determined by number of dozens plus value of loose eggs
        TotalPrice = ((EggsDozens * 3.25) + (EggsRemainder * .45));
        
        //Output message explaining number of eggs total, number of dozens
        // and number of loose eggs.
   
        System.out.println("You ordered " +NumberofEggs+ " eggs");
        System.out.println("That's " +EggsDozens+ " dozen eggs " 
        + "at $3.25 per dozen and " +EggsRemainder+ " loose eggs at $.45"
        +" per egg");
        
        //Output message giving value of total order.
        System.out.println("Your total is: $" +TotalPrice);

    }
    
}
